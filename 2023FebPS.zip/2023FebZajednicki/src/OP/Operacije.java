/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package OP;

/**
 *
 * @author Korisnik
 */
public interface Operacije {

    public static int LOGIN=0;
    public static int ONLINE=1;
    public static int LOGOUT=2;
    public static int SENDMSG=3;
    
}
